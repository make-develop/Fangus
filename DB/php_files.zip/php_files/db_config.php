<?php
define('DB_USER', "makedeve_mike"); // Usuario
define('DB_PASSWORD', "Proyectox1116"); // Password
define('DB_DATABASE', "makedeve_fangus"); // Nombre de la base de datos
define('DB_SERVER', "127.0.0.1"); // db server
?>