<?php

	require 'Database.php';

	class Amigos{
			function __construct(){}

		public static function ObtenerTodosLosUsuarios($nameTable){
			$consultar = "SELECT $nameTable.id, $nameTable.estado, $nameTable.fecha_amigos,
			DatosPersonales.nombre,DatosPersonales.apellidos 
			FROM $nameTable,DatosPersonales
			WHERE $nameTable.id = DatosPersonales.id";

			$resultado = Database::getInstance()->getDb()->prepare($consultar);
			$resultado->execute();
			return  $resultado->fetchAll(PDO::FETCH_ASSOC);
			return $tabla;

		}
	}
?>
